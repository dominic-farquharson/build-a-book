// importing react and component
import React, {Component} from 'react';

// creating Resource component
class Resource extends Component {
  constructor() {
    super();
  }

  render() {
    return (
      <div>Resource.js
        {/* <a href="http://google.com">Test</a> */}
     </div>
    )
  }
}



export default Resource;
